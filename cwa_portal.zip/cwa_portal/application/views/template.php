<?php $this->load->view('layout/head') ?>
<body>
	<?php $this->load->view('layout/navbar') ?>
	
	<?php $this->load->view($content) ?>
	<hr>
	<div class="container">
		<div class="row">
			<br><br><br>
		</div>
	</div>
</body>
</html>